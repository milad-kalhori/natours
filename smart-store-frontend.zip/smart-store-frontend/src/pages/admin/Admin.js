import React, {useEffect, useState} from 'react';
//import useStyle from './styles'
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import SupervisorAccountIcon from '@material-ui/icons/SupervisorAccount';
import {useTranslation} from "react-i18next";
import NewGoods from "../home/components/NewGoods";
import {toast} from "react-toastify";
import {getAllGoods} from "../../api/api_goods";
import {setGoodsList, useGoodsState, useGoodsDispatch} from "../../context/StoreContext";
import {Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import GoodsList from "../home/components/GoodsList";
import Button from "@material-ui/core/Button";


import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';



const Admin = (props) => {

    const {t} = useTranslation();


    const getImage = () => {
        if ( localStorage.getItem("image") !== "undefined")
            return localStorage.getItem("image");
        else return "/images/male_user.png";
    };

    const [name, setName] = React.useState(localStorage.getItem("name"));
    const [image, setImage] = React.useState(getImage);

    const goodsDispatch = useGoodsDispatch();


    useEffect(() => {
        updateGoods();
    }, []);


    const updateGoods = () => {
        getAllGoods((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.goodsFetch"));
            setGoodsList(goodsDispatch,data);
        })
    }


    const goToChat = () => {
        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        toast.success("chat")
        props.history.push({
            pathname:"admin/chatroom",
            state: {
                name,
                image
            }
        })
    }

    const goToHistory = () => {

        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        toast.success("history")
        window.location.assign('/admin/history');
    }

    const goToRouteInformation = () => {
        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        toast.success("map")
        window.location.assign('/admin/routeInformation');
    }


    const goToMap = () => {
        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        toast.success("map")
        window.location.assign('/map');
    }


    const goToGuide = () => {
        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        toast.success("guide")
        window.location.assign('/guide');
    }


    const sendData = ()=> {
        getAllGoods((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.goodsFetch"));
            //Send Data
            toast.success("اطلاعات ارسال شد")
        })
    }



    const useStyles = makeStyles({
        root: {
            maxWidth: 345,
        },
    });

    const classes = useStyles();




    return (
        <div>
            <Header title={t("admin")} icon={<SupervisorAccountIcon/>}/>
            <Divider className={classes.divider}/>

            <Grid container direction={"row"} justify={"space-between"} >

                <Grid item>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                                component="img"
                                alt="Contemplative Reptile"
                                height="140"
                                image="/images/card/3.jpg"
                                title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2">
                                    ارتباط با مشتریان
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    در این قسمت شما میتوانید با مشتریان فروشگاه به صورت پیام متنی ارتباط برقرار کنید.
                                    راهنمایی ها، سوالات، انتقادات و پیشنهادات آن ها را به صورت متنی در صفحه چت پاسخ دهید.
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                            <Button style={{border :"solid 1px" }} color="primary" onClick={goToChat}>
                                ورود به چت روم
                            </Button>
                        </CardActions>
                    </Card>
                </Grid>


                <Grid item>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                                component="img"
                                alt="Contemplative Reptile"
                                height="140"
                                image="/images/card/555.jpeg"
                                title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2">
                                    مشاهده سوابق خرید مشتریان
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    در این قسمت شما می توانید سوابق خرید مشتریان را از پایگاه داده دریافت و آن را مشاهده کنید.
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                            <Button style={{border :"solid 1px" }}   color="primary" onClick={goToHistory}>
                                مشاهده سوابق خرید
                            </Button>

                        </CardActions>
                    </Card>
                </Grid>


                <Grid item>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                                component="img"
                                alt="Contemplative Reptile"
                                height="140"
                                image="/images/card/111.png"
                                title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2">
                                    مشاهده نقشه فروشگاه
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    در این قسمت شما می توانید نقشه فروشگاه و مکان قفسه ها و محصولات غذایی را مشاهده کنید.
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                            <Button style={{border :"solid 1px" }}  color="primary" onClick={goToMap}>
                                نمایش نقشه فروشگاه
                            </Button>

                        </CardActions>
                    </Card>
                </Grid>

                <Grid item>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                                component="img"
                                alt="Contemplative Reptile"
                                height="140"
                                image="/images/card/2.jpg"
                                title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2">
                                    تحلیل مسیر حرکت مشتریان در فروشگاه
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    در این قسمت شما می توانید نقشه مسیر حرکت مشتریان در فروشگاه را مشاهده کنید.
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                            <Button style={{border :"solid 1px" }}  color="primary" onClick={goToRouteInformation}>
                                نمایش نقشه مسیر حرکت مشتریان
                            </Button>

                        </CardActions>
                    </Card>
                </Grid>

                <Grid item>
                    <Card className={classes.root}>
                        <CardActionArea>
                            <CardMedia
                                component="img"
                                alt="Contemplative Reptile"
                                height="140"
                                image="/images/card/666.jpg"
                                title="Contemplative Reptile"
                            />
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="h2">
                                     اطلاعات کالا ها به قفسه ها
                                </Typography>
                                <Typography variant="body2" color="textSecondary" component="p">
                                    در این قسمت شما می توانید اطلاعات کالا ها را به قفسه ها ارسال کنید.
                                </Typography>
                            </CardContent>
                        </CardActionArea>
                        <CardActions>
                            <Button style={{border :"solid 1px" }}  color="primary" onClick={sendData}>
                                ارسال اطلاعات
                            </Button>

                        </CardActions>
                    </Card>
                </Grid>


            </Grid>




        </div>
    );
};

export default Admin;
import React, {useEffect, useState} from 'react';
import useStyle from './styles'
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";

import PersonIcon from '@material-ui/icons/Person';
import {useTranslation} from "react-i18next";


import NewGoods from "../home/components/NewGoods";
import {toast} from "react-toastify";
import {getAllGoods} from "../../api/api_goods";
import {setGoodsList, useGoodsState, useGoodsDispatch} from "../../context/StoreContext";
import {Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";



const Staff = () => {
    const classes = useStyle();
    const {t} = useTranslation();

    const goodsDispatch = useGoodsDispatch();

    useEffect(() => {
        updateGoods();
    }, []);


    const updateGoods = () => {
        getAllGoods((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.goodsFetch"));
            setGoodsList(goodsDispatch,data);
        })
    }
    //


    return (
        <div className={classes.root}>
            <Header title={t("staff")} icon={<PersonIcon/>}/>
            <Divider className={classes.divider}/>



            <NewGoods updateGoods={updateGoods}/>



        </div>
    );
};

export default Staff;
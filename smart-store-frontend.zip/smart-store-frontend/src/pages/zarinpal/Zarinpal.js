import React, {useState} from 'react';
import Iframe from "react-iframe";
import './style.css'
import Header2 from "../../components/header/Header2";
import Divider from "@material-ui/core/Divider";
import CreditCardIcon from '@material-ui/icons/CreditCard';


const Zarinpal = () => {


    const url = localStorage.getItem('url');

    // C+R
    if (localStorage.getItem("bill") !== undefined && localStorage.getItem("bill") !== null) {
           window.location.assign(localStorage.getItem("bill"));
       }


    return (
        <div id={"main"}>
            <Header2  id={"head"} title={'Zarinpal'} icon={<CreditCardIcon/>}/>
            <Divider style={{marginLeft: -250, marginRight: -250}}/>

            <Iframe url={url}
                    width="993px"
                    height="745px"
                    id="myId"
                    className="myClassname"
                    display="initial"
                    position="relative"
            />

        </div>
    );
};

export default Zarinpal;

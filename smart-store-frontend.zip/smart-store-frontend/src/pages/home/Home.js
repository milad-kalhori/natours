import React, {useEffect, useState} from 'react';
import useStyle from './styles'
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import {Home as HomeIcon} from "@material-ui/icons";
import {useTranslation} from "react-i18next";
import Slideshow from "./components/Slideshow";


//
import NewGoods from "./components/NewGoods";
import {toast} from "react-toastify";
import {getAllGoods} from "../../api/api_goods";
import {setGoodsList, useGoodsState, useGoodsDispatch} from "../../context/StoreContext";
import {Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import GoodsList from "./components/GoodsList";
import Iframe from "react-iframe";
//


const Home = () => {

    const classes = useStyle();
    const {t} = useTranslation();
    const goodsDispatch = useGoodsDispatch();
    useEffect(() => {
        updateGoods();

    }, []);
    const updateGoods = () => {
        getAllGoods((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.goodsFetch"));
            setGoodsList(goodsDispatch, data);
        })
    }
  return (
    <div className={classes.root}>
      <Header title={t("home")} icon={<HomeIcon/>}/>
        <Divider className={classes.divider} />
        <Slideshow/>
    </div>
  );
};

export default Home;

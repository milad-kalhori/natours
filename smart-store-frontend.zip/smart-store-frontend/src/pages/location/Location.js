import React from 'react';
import Iframe from "react-iframe";
import {updateCoordinates} from "../../api/api_goods";
import {toast} from "react-toastify";
import {Typography} from "@material-ui/core";
import Header from "../../components/header/Header";
import LocationOnIcon from '@material-ui/icons/LocationOn';
import Divider from "@material-ui/core/Divider";
import useStyle from "../home/styles";


const Location = () => {

   const sendCoordinates = () =>
    {
        const body = {
            coordinates: JSON.parse(localStorage.getItem('coordinates'))
        };


        updateCoordinates(body, (isOk, data) => {
            if (!isOk)
                return toast.error(data);
            console.log(data)
            toast.success("مختصات شما ارسال شد");
        });

    }

    const classes = useStyle();
    return (
        <div>
            <Header  title={"Location"} icon={<LocationOnIcon/>}/>
            <Divider className={classes.divider} />
            <Typography>به منظور کمک کردن به بهبود خدمتگذاری، و همچنین مشاهده مسیر حرکت خود در فروشگاه توسط مدیر و برای پیدا کردن اشیاء گم شده، پس از فشار دادن دکمه شروع، این صفحه را تا لحظه خروج از فروشگاه در یک تب جدا باز نگه دارید و در نهایت دکمه ارسال را بزنید. </Typography>
            <button onClick={sendCoordinates} style={{backgroundColor:"skyblue"}}>ارسال</button>

            <Iframe url="/tracking/tracking.html"
                    width="773px"
                    height="745px"
                    id="myId3"
                    className="myClassname"
                    display="initial"
                    position="relative"/>

        </div>
    );
};

export default Location;


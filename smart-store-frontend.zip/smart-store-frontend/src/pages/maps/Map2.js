import React from 'react';
import Iframe from "react-iframe";

const Map2 = () => {
    return (
        <div>
            <Iframe url="/map2/index.html"
                    width="770px"
                    height="740px"
                    id="myId4"
                    className="myClassname"
                    display="initial"
                    position="relative"
            />
        </div>
    );
};

export default Map2;
import { makeStyles } from "@material-ui/styles";

export default makeStyles(theme => ({
  mapContainer: {
    width : "772px",
    height: "700px",
    margin: -theme.spacing(1) * 3,
    marginTop:"5px",
    marginRight:"5px",
    marginBottom:"5px",
    marginLeft:"5px",
  },
}));
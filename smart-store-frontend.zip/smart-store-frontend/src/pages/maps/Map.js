import React, {useState} from "react";
import {
  withGoogleMap,
  withScriptjs,
  GoogleMap,
  Marker,
} from "react-google-maps";

// styles
import useStyles from "./styles";

const BasicMap = withScriptjs(

  withGoogleMap(() => (




      <GoogleMap

      defaultZoom={18}
      defaultCenter={{
        lat: parseFloat(  33.902132193403716),
        lng: parseFloat(48.73492809585109),
      }}
    >

        <Marker position={{ lat: 33.90184496487553, lng: 48.734951245855676 }}   title={"book"} />
        <Marker position={{ lat: 33.901893385107776, lng: 48.734516727996514 }}   title={"sport"} />
        <Marker position={{ lat: 33.90176482098203, lng: 48.73419486287424 }}    title={"game"} />
        <Marker position={{ lat: 33.90167131967775, lng: 48.73435713652806 }}    title={"1"} />
        <Marker position={{ lat: 33.901656849228644, lng: 48.734666931685354 }}    title={"2"} />
        <Marker position={{ lat: 33.90184051243899, lng: 48.73526372322212 }}    title={"3"} />
        <Marker position={{ lat: 33.90200970486443, lng: 48.73509608514999 }}    title={"4"} />
        <Marker position={{ lat: 33.901773725862824, lng: 48.73457037215581 }}    title={"5"} />
        <Marker position={{ lat: 33.90154108554388, lng: 48.73459853534761 }}    title={"6"} />






    </GoogleMap>
  )),
);


export default function Map({lat,lon}) {

  /*
   setTimeout(function(){
        window.location.reload(1);
    }, 5000);
   */


  let classes = useStyles();

  return (
    <div className={classes.mapContainer}>
        <BasicMap

        googleMapURL="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=AIzaSyB7OXmzfQYua_1LEhRdqsoYzyJOPh9hGLg"
        loadingElement={<div style={{ height: "inherit", width: "inherit" }} />}
        containerElement={<div style={{ height: "100%" }} />}
        mapElement={<div style={{ height: "100%" }} />}
      />
    </div>
  );
}

/*
home :
//33.89043821975461, 48.73659374819549
museum tehran :
//35.687222,51.415279
city center :
<Marker position={{ lat: 32.551877382254105, lng: 51.688652777853946 }} />
<Marker position={{ lat: 32.5516829492612, lng: 51.68900682946227 }} />
<Marker position={{ lat: 32.55189546902273, lng: 51.68972029709723 }} />
<Marker position={{ lat: 32.552306942024366, lng: 51.69065907030115 }} />
 */

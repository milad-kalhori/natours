import React from 'react';
import Iframe from 'react-iframe'
import Header from "../../../components/header/Header";
import ListIcon from "@material-ui/icons/List";
import Divider from "@material-ui/core/Divider";
import useStyles from "../../home/styles";
import CropFreeIcon from '@material-ui/icons/CropFree';


const Qrcode = () => {

    const classes = useStyles();
    return (
        <div>
            <Header title={"Generate QR"} icon={<CropFreeIcon/>}/>
            <Divider className={classes.divider}/>
            <Iframe url="/qrCode/index.html"
                    width="773.9px"
                    height="700px"
                    id="myId1"
                    className="myClassname"
                    display="initial"
                    position="relative"/>
        </div>
    );
};

export default Qrcode;



import React, {useState} from 'react';
import Iframe from "react-iframe";
import {checkoutBasket} from "../../../api/api_goods";
import {toast} from "react-toastify";
import Header from "../../../components/header/Header";
import ListIcon from "@material-ui/icons/List";
import Divider from "@material-ui/core/Divider";
import useStyles from "../../home/styles";
import CropFreeIcon from '@material-ui/icons/CropFree';


const Qrcode2 = () => {

    const classes = useStyles();
    return (
        <div>
            <Header title={"Scan QR"} icon={<CropFreeIcon/>}/>
            <Divider className={classes.divider}/>
            <Iframe url ="https://pageloot.com/fa/qr-code-scanner/#upload"
                    width="773.9px"
                    height="7000"
                    id="myId2"
                    className="myClassname"
                    display="initial"
                    position="relative"/>
            
        </div>
    );
};

export default Qrcode2;
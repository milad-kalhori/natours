import React from 'react';
import {likeGoodsRequest} from "../../api/api_goods";
import {toast} from "react-toastify";
import {likeGoods} from "../../context/StoreContext";

const ShoppingCart = () => {


    return (
        <div>
            <img src={'images/pay1.png'}  style={{width : 760}}/>
            <img src={'images/pay2.png'}  style={{width : 760}}/>
        </div>
    );
};

export default ShoppingCart;
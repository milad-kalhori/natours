import React, {useEffect, useState} from 'react';
import {toast} from "react-toastify";
import Header from "../../components/header/Header";
import TransferWithinAStationIcon from '@material-ui/icons/TransferWithinAStation';
import Divider from "@material-ui/core/Divider";
import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import useStyle from "../admin/styles";
import {useTranslation} from "react-i18next";
import {getUsers} from "../../api/api_goods";

const RouteInformation = () => {
    const {t} = useTranslation();
    const classes = useStyle();

    const [users,setUsers] = useState([]);



    useEffect(() => {
        getUsers((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.userFetchError"));
            setUsers(data)
        })

    }, []);


    const goToMap2 = () => {
        if (localStorage.getItem("role") !== "admin")
            return toast.error("شما Admin نیستی");

        // TEST
        const number = parseInt(document.getElementById("number").value);

        if (number===1) {
            let coordinates = [
                [48.73509608514999, 33.90200970486443], [48.73526372322212, 33.90184051243899],
                [48.734951245855676, 33.90184496487553], [48.73457037215581, 33.901773725862824],
                [48.73435713652806, 33.90167131967775], [48.73459853534761, 33.90154108554388]
            ];
            localStorage.setItem("coordinates", JSON.stringify(coordinates));
        }
/*

  */

        if (number===2) {
            let coordinates = [
                [48.73536363249123, 33.902088182208246], [48.73527511958914, 33.90189672777276],
                [48.73492911460827, 33.90182326258454], [48.7346769869478, 33.90165406978908],
                [48.734483867888706, 33.901616223986245], [48.73439803719578, 33.90152272251902],
                [48.73494520787376, 33.90131123071072], [48.73570695527349, 33.90114648937219],
                [48.73575255282786, 33.90073018213616], [48.73569086201648, 33.900358398017026],
                [48.73564928777725, 33.899976594070175], [48.73519188661162, 33.899965522256615],
                [48.73503900068984,33.89977851559915], [48.73485332892872, 33.89978345932437],
                [48.7346387521964,33.89981907966961], [48.73451268836616,33.899925940616136],
                [48.734488548483775, 33.90013075705593], [48.73426592512399,33.900213128746266],
                [48.73392260235228,33.900344478033794], [48.73314476172735,33.89925360492183],
                [48.7338749219757,33.89892584908544 ], [48.734837835036814,33.89881008169054 ],
                [48.735604946833,33.898834570958236 ], [48.73539573451038,33.89667058295022 ],
                [48.73602605363206,33.895975957872324], [48.7386666883695,33.8939265582846],
                [48.738666688372824,33.89350910257588 ], [48.7364183941124,33.89133037612687 ],
                [48.736748305822275,33.89115225651945 ], [ 48.736256120459004,33.89063682081005],
                [48.73641302969452,33.890494323997736 ], [48.736497519282864,33.89058783755766 ]

            ];
            localStorage.setItem("coordinates", JSON.stringify(coordinates));
        }

        //

        toast.success("map2");
        window.location.assign('/maps2');
    }

    return (
        <div>
            <Header title={"تحلیل مسیر حرکت مشتری"} icon={<TransferWithinAStationIcon/>}/>
            <Divider className={classes.divider}/>

            <Typography> نام مشتری </Typography>
            <input type={"text"} placeholder={"نام کاربری مشتری "}/>
            <Typography> شماره مسیر ثبت شده </Typography>
            <input id={"number"} type={"number"} placeholder={"شماره مسیر "}/>

            <br/>
            <br/>
            <Grid item container>
            <Grid item><Button style={{marginRight:"5px"}} variant="contained" color="primary" onClick={goToMap2}>
                مشاهده نقشه
            </Button></Grid>
            </Grid>
            <br/>
            <Divider className={classes.divider}/>

            {
                users.map((item, index) => {

                    if (item.role !== 'user') return

                    let number = item.history.length;

                    return (
                        <div>
                            <Typography> نام کاربر : {item.name} </Typography>
                            <Typography> تعداد مسیر های ثبت شده : {number} </Typography>
                            {index !== users.length - 1 &&
                            <Divider style={{marginLeft: -24, marginRight: -24}}/>
                            }
                        </div>)


                })
            }

            <Divider style={{marginLeft: -24, marginRight: -24}}/>
        </div>
    );
};

export default RouteInformation;





import React, {useEffect, useState} from 'react';
//import useStyle from './styles'
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import PersonIcon from '@material-ui/icons/Person';
import {useTranslation} from "react-i18next";
import {toast} from "react-toastify";
import {getAllGoods} from "../../api/api_goods";
import {setGoodsList, useGoodsState, useGoodsDispatch} from "../../context/StoreContext";
import {Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";


import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';





const User = (props) => {


    const {t} = useTranslation();

    const getImage = () => {
        if ( localStorage.getItem("image") !== "undefined")
            return localStorage.getItem("image");
        else return "/images/male_user.png";
    };

    const [name, setName] = React.useState(localStorage.getItem("name"));
    const [image, setImage] = React.useState(getImage);


    const goodsDispatch = useGoodsDispatch();

    useEffect(() => {
        updateGoods();
    }, []);


    const updateGoods = () => {
        getAllGoods((isOk, data) => {
            if (!isOk)
                return toast.error(t("error.goodsFetch"));
            setGoodsList(goodsDispatch,data);
        })
    }


    const submit = () => {
        if (localStorage.getItem("role") !== "user")
            return toast.error("شما User نیستی");

        toast.success("chat")
        props.history.push({
            pathname:"/user/chatroom",
            state: {
                name,
                image
            }
        })

    }

    const barcode = () => {
        if (localStorage.getItem("role") !== "user")
            return toast.error("شما User نیستی");

        toast.success("barcode")
        window.location.assign("/user/qrcode-scanner");
    }

    const map = () => {
        if (localStorage.getItem("role") !== "user")
            return toast.error("شما User نیستی");

        toast.success("map")
        window.location.assign("/map");
    }

    const guide = () => {
        if (localStorage.getItem("role") !== "user")
            return toast.error("شما User نیستی");

        toast.success("guide")
        window.location.assign("/user/guide");
    }

    const allow = () => {
        if (localStorage.getItem("role") !== "user")
            return toast.error("شما User نیستی");

        toast.success("allow location")
        window.location.assign("/user/location");
    }

    const useStyles = makeStyles({
        root: {
            maxWidth: 345,
        },
    });

    const classes = useStyles();

    return (
        <div>
            <Header title={t("user")} icon={<PersonIcon/>}/>
            <Divider className={classes.divider}/>


    <Grid container direction={"row"} justify={"space-between"} >

        <Grid item>
            <Card className={classes.root}>
            <CardActionArea>
            <CardMedia
            component="img"
            alt="Contemplative Reptile"
            height="140"
            image="/images/card/3.jpg"
            title="Contemplative Reptile"
            />
            <CardContent>
            <Typography gutterBottom variant="h5" component="h2">
            ارتباط با مدیر فروشگاه
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p">
            در این قسمت شما میتوانید با مدیر فروشگاه به صورت پیام متنی ارتباط برقرار کنید.
                راهنمایی ها، سوالات، انتقادات و پیشنهادات خود را به صورت متنی در صفحه چت وارد کنید
                و در کمترین زمان پاسخ آن ها را دریافت نمایید.
            </Typography>
            </CardContent>
            </CardActionArea>
            <CardActions>
            <Button style={{border :"solid 1px" }} color="primary" onClick={submit}>
            ورود به چت روم
            </Button>
            </CardActions>
            </Card>
        </Grid>


        <Grid item>
            <Card className={classes.root}>
                <CardActionArea>
                    <CardMedia
                        component="img"
                        alt="Contemplative Reptile"
                        height="140"
                        image="/images/card/7.jpg"
                        title="Contemplative Reptile"
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="h2">
                         مشاهده اطلاعات محصولات
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p">
                            در این قسمت شما می توانید با عکسبرداری از تصویر بارکد محصولات توسط دوربین گوشی هوشمند خود،
                            بارکد محصولات را اسکن کنید و اطلاعات محصولات فروشگاه را مشهاده و بررسی کنید.
                        </Typography>
                    </CardContent>
                </CardActionArea>
                <CardActions>
                    <Button style={{border :"solid 1px" }}   color="primary" onClick={barcode}>
                        ورود به بارکد خوان
                    </Button>

                </CardActions>
            </Card>
        </Grid>


        <Grid item>
            <Card className={classes.root}>
            <CardActionArea>
            <CardMedia
            component="img"
            alt="Contemplative Reptile"
            height="140"
            image="/images/card/111.png"
            title="Contemplative Reptile"
            />
            <CardContent>
            <Typography gutterBottom variant="h5" component="h2">
            مشاهده نقشه فروشگاه
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p">
            در این قسمت شما می توانید نقشه فروشگاه و مکان قفسه ها و محصولات غذایی را مشاهده کنید.
            </Typography>
            </CardContent>
            </CardActionArea>
            <CardActions>
            <Button style={{border :"solid 1px" }}  color="primary" onClick={map}>
            نمایش نقشه فروشگاه
            </Button>

            </CardActions>
            </Card>
        </Grid>


        <Grid item>
            <Card className={classes.root}>
                <CardActionArea>
                    <CardMedia
                        component="img"
                        alt="Contemplative Reptile"
                        height="140"
                        image="/images/card/2.jpg"
                        title="Contemplative Reptile"
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="h2">
                            اجازه دسترسی به لوکیشن شما
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p">
                            در این قسمت شما می توانید اجازه دسترسی سایت به مختصات لوکیشن خود بدهید تا مسیر حرکت شما بر روی نقشه ثبت شود.
                        </Typography>
                    </CardContent>
                </CardActionArea>
                <CardActions>
                    <Button style={{border :"solid 1px" }}   color="primary" onClick={allow}>
                        مجوز دسترسی
                    </Button>

                </CardActions>
            </Card>
        </Grid>



        <Grid item>
            <Card className={classes.root}>
                <CardActionArea>
                    <CardMedia
                        component="img"
                        alt="Contemplative Reptile"
                        height="140"
                        image="/images/card/444.png"
                        title="Contemplative Reptile"
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="h2">
                            راهنمای سایت
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p">
                            در این قسمت شما می توانید ویدیوی راهنمای استفاده از سایت را مشاهده کنید.
                        </Typography>
                    </CardContent>
                </CardActionArea>
                <CardActions>
                    <Button style={{border :"solid 1px" }}   color="primary" onClick={guide}>
                        نمایش راهنمای سایت
                    </Button>

                </CardActions>
            </Card>
        </Grid>


    </Grid>




        </div>
    );
};

export default User;
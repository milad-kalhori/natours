import 'https://api.mapbox.com/mapbox-gl-js/v2.3.1/mapbox-gl.js';

//localStorage.getItem("latitude");
//localStorage.getItem("longitude");
//{ lat: 33.89043821975461, lng: 48.73659374819549 }

/*[localStorage.getItem("longitude"),localStorage.getItem("latitude")],
    [48.736626,33.890963],
    [48.736615,33.891301],
    [48.736229,33.891203],
    [48.734555,33.889457],
    [48.737269,33.883908]
 */


/*
const coordinates = [

    [-122.483696, 37.833818],
    [-122.483482, 37.833174],
    [-122.483396, 37.8327],
    [-122.483568, 37.832056],
    [-122.48404, 37.831141],
    [-122.48404, 37.830497],
    [-122.483482, 37.82992],
    [-122.483568, 37.829548],
    [-122.48507, 37.829446],
    [-122.4861, 37.828802],
    [-122.486958, 37.82931],
    [-122.487001, 37.830802],
    [-122.487516, 37.831683],
    [-122.488031, 37.832158],
    [-122.488889, 37.832971],
    [-122.489876, 37.832632],
    [-122.490434, 37.832937],
    [-122.49125, 37.832429],
    [-122.491636, 37.832564],
    [-122.492237, 37.833378],
    [-122.493782, 37.833683]

];
*/

const coordinates = JSON.parse(localStorage.getItem("coordinates"));


mapboxgl.accessToken = 'pk.eyJ1IjoibWlsYWQ3a2FsaG9yaSIsImEiOiJja3M4MGNyNWswYzhpMm5sdXcxdzN1dXFzIn0.Z50_XoLRArivH8TPaAtHfQ';
const map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11',
    center: coordinates[0] ,
    zoom: 15
});

map.on('load', () => {
    map.addSource('route', {
        'type': 'geojson',
        'data': {
            'type': 'Feature',
            'properties': {},
            'geometry': {
                'type': 'LineString',
                'coordinates': coordinates
            }
        }
    });
    map.addLayer({
        'id': 'route',
        'type': 'line',
        'source': 'route',
        'layout': {
            'line-join': 'round',
            'line-cap': 'round'
        },
        'paint': {
            'line-color': '#888',
            'line-width': 8
        }
    });
});